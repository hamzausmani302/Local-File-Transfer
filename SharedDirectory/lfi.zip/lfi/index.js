const dotenv = require("dotenv");
const express = require("express");
const path = require("path");
const router = require(path.resolve(__dirname, "./routes/routes.js"));
const cors = require("cors");

const app = express();
app.use(router);
app.use(cors({origin:"*"}));

dotenv.config();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.listen(process.env.PORT, () => {
  console.log(`connected to ${process.env.PORT}`);
});
