const fs = require("fs");
const path = require("path");
const { off } = require("process");

const GetContentFromFile = (filename) => {
  try {
    const data = fs.readFileSync(filename, "utf8");
    return data;
  } catch (err) {
    return null;
  }
};
const replaceandGetContent = (filename, oldcontent, newcontent) => {
  let data = GetContentFromFile(filename);

  if (data != null) {
    data = data.replace(oldcontent, newcontent);
  }
  return data;
};
const readDir = (dirPath) => {
  const pr = new Promise((resolve, reject) => {
    fs.readdir(dirPath, function (err, files) {
      //handling error
      if (err) {
        reject(err);
      }
      //listing all files using forEach
      resolve(files);
    });
  });
  return pr;
};
const accepted_extension = ["gif", "png", "jpg", "jpeg", "webp", "plain"];
const checkFileExtensionAndAction = (file) => {
  const mimetype = file.originalname.split(".");
  const extension = mimetype[mimetype.length - 1];
  for (let i = 0; i < accepted_extension.length; i++) {
    if (extension === accepted_extension[i]) {
      return true;
    }
  }
  fs.unlinkSync(path.resolve(__dirname, `../media/${file.filename}`));
  return false;
};
module.exports.CheckFileAndAction = checkFileExtensionAndAction;
module.exports.ReadDir = readDir;
module.exports.ReadFile = GetContentFromFile;
module.exports.ReplaceFileContent = replaceandGetContent;
