const express = require("express");
const path = require("path");
const fs = require("fs");
const multer = require("multer");
const {
  ReadDir,
  ReadFile,
  CheckFileAndAction,
  ReplaceFileContent,
} = require("../Service/FileService");
const router = express.Router();
var storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, path.resolve(__dirname, "../media"));
  },
  filename: function (req, file, cb) {
    cb(null, +Date.now() + "-" + file.originalname);
  },
});

var upload = multer({ storage: storage });

router.get("/media", (req, res) => {
  const image = req.query.image;
  //sanitize  input later     //important
  console.log(image);
  res.sendFile(path.resolve(__dirname, `../media/${image}`));
});
router.post("/upload1", upload.single("myfile"), (req, res) => {
  //store image in db
  console.log("file", req.file);

  if (req.file) {
    const result = CheckFileAndAction(req.file);
    if (result) {
      res.send(
        "<h1>successfully uploaded</h1> <a href='/'>Click to go back</a>"
      );
    }
  }
  const data1 = ReplaceFileContent(
    path.resolve(__dirname, "../Views/homepage.html"),
    "Upload file here",
    "<div style='color:red;'>Select valid file</div>"
  );

  res.send(data1);
});

router.get("/viewGallery", async (req, res) => {
  ReadDir(path.resolve(__dirname, "../media"))
    .then((data) => {
      let files = ``;

      for (let i = 0; i < data.length; i++) {
        let template = `<a style="margin:10;padding:10;" href="{link}"><img style="width:100;height:100;" src='${process.env.DOMAIN}/media?image={name}' /></a>`;
        data[i] = data[i].replace("/", "");
        template = template.replace(
          "{link}",
          `${process.env.DOMAIN}/media?image=${data[i]}`
        );
        template = template.replace("{name}", data[i]);
        template = template.replace("<script>", "");
        files += template;
      }
      res.send(files);
    })
    .catch((err) => {
      res.send(err);
    });
});

router.get("/", (req, res) => {
  res.sendFile(path.resolve(__dirname, "../Views/homepage.html"));
});

module.exports = router;
